package com.Yoshi.Athlete;
import javax.swing.JOptionPane;
public class Football extends Athlete {
	private double vertical;
	private int benchpress;
	private double fortyrun;
	private String position;
	private static final double offer = 2000000.45; //minimum amount for offer and sponsor is unchangable. 
	private static final double spmin = 345000.76;
	
	public Football(String n, double h, double w, double v, int b, double f, String p) {
		super(n,h,w); //inherited attributes
		//unique attributes
		vertical = v; 
		benchpress = b;
		fortyrun = f;
		position = p;
	}
	
	
	public void obtainSponser() {
		//ask users which company support him
		String sentence = JOptionPane.showInputDialog("Which company would like me to represents them?");
    	if(sentence.contains("would")) {
    		int index1 = sentence.indexOf("would") - 2;
    		//extract company name
    		String company = sentence.substring(0, index1);
    		//ask for amount user want and compare with minimum amount
    		double minimum = Double.parseDouble(JOptionPane.showInputDialog(" How much is contract amount?"));
    				if(minimum > spmin) {
    					JOptionPane.showMessageDialog(null, "I want to contract with " + company);
    				}
    				else if(minimum < spmin) {
    					JOptionPane.showMessageDialog(null, "that's less than minimum value");
    				}
    				
    			
    			
    		}
    		
    	}
    	
		
	
		
    public void sign_contract() {
    	//print Athlete Data
    	this.printData();
    	//list of teams
    	String[] Teams = {"Green Bay Pachers", "Kansas City Chiefs", "Tampa Bay Buccaneers","Tennesse Titans", "Buffalo Bills", "Dallas Cowboys", "Cincinnati Bengals", "Los Angeles Rams" };
    	//ask user where he got offer from
    	String sentence = JOptionPane.showInputDialog("Did I get offer from any NFL team?");
    	if(sentence.contains("you have an offer from the")) {
    		int index1 = sentence.indexOf("the") + 4;
    		//extract team name
    		String thisTeam = sentence.substring(index1);
    		
    		//find team name from the list, this time I just have eight teams name.
    		for(String x:Teams) {
    			if(thisTeam.equals(x)) {
    				double minimum = Double.parseDouble(JOptionPane.showInputDialog("Great you got offer from one of the best team.\n What is your minimum amount for"));
    				if(minimum > offer) {
    					JOptionPane.showMessageDialog(null, "I want to contract with " + thisTeam);
    				}
    				else if(minimum < offer) {
    					JOptionPane.showMessageDialog(null, "that's less than minimum");
    				}
    				break;
    				
    			}
    			
    	}
    	
    }
    	else {
    		JOptionPane.showMessageDialog(null, "You are typing wrong way");
    	}

    	
}
    public void printData() {
    	System.out.println("Athlete Data:" + "\n name: " + name + "\n Height: " + height + "\n Weight: " + weight);
    	System.out.println("Potential: \n Position: " + position + "\n vertical: " + vertical + "\n Bench Press: " + benchpress + "\n 40 run: " + fortyrun);
    }
    
    //getters and setters
    
    public void MakeTackle() {
    	System.out.println("Tackle!");
    }
    
    public String getName() {
    	return super.name;
    }

    public void setName(String newName) {
    	super.name = newName;
    }
    
    public double getHeight() {
    	return super.height;
    }
    
    public void setHeight(double newHeight) {
    	super.height = newHeight;
    }
    
    public double getWeight() {
    	return super.weight;
    }
     public void setWeight(double newWeight) {
    	 super.weight = newWeight;
     }

	public double getVertical() {
		return vertical;
	}


	public void setVertical(double vertical) {
		this.vertical = vertical;
	}


	public int getBenchpress() {
		return benchpress;
	}


	public void setBenchpress(int benchpress) {
		this.benchpress = benchpress;
	}


	public double getFortyrun() {
		return fortyrun;
	}


	public void setFortyrun(double fortyrun) {
		this.fortyrun = fortyrun;
	}


	public String getPosition() {
		return position;
	}


	public void setPosition(String position) {
		this.position = position;
	}
    
    
}
