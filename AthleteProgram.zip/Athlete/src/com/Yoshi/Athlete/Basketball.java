package com.Yoshi.Athlete;

import javax.swing.JOptionPane;

public class Basketball extends Athlete{
	private double ppg;
	private double vertical;
	private double shootP;
	private static final double offer = 2000000.45;
	private static final double spmin = 345000.76;
	
	public Basketball(String n, double h, double w, double p, double v, double s ) {
		super(n,h,w);
		ppg = p;
		vertical = v;
		shootP = s;
		
	}
	
    public void obtainSponser() {
    	
    	int s = 0;
    	do {
    	String sentence = JOptionPane.showInputDialog("Which company can be my sponsor");
    	if(sentence.contains("would")) {
    		int index1 = sentence.indexOf("would") - 1;
    		
    		String company = sentence.substring(0, index1);
    		double minimum = Double.parseDouble(JOptionPane.showInputDialog(" How much is contract amount?"));
    		
    				if(minimum > spmin) {
    					JOptionPane.showMessageDialog(null, "I would like to contract with " + company);
    					s += 4;
    				}
    				else if(minimum > spmin) {
    					JOptionPane.showMessageDialog(null, "I want to contract with " + company + " but less than minimum"); 
    					s += 4;
    				}
    				
    			
    			
    		}
    	else {
    		JOptionPane.showMessageDialog(null, "You are typing wrong way");
    		s ++;
    	}}while(s <= 3);
	}
		
    public void sign_contract() {
    	this.printData();
    	String[] Teams = {"Suns", "Worriors", "Bucks","Nets", "Heat", "Bulls", "Grizzlies", "Jazz" };
    	String sentence = JOptionPane.showInputDialog("Did I get offer from any NBA team?");
    	if(sentence.contains("you have an offer from the")) {
    		int index1 = sentence.indexOf("the") + 4;
    		
    		String thisTeam = sentence.substring(index1);
    		System.out.println(thisTeam);
    		for(String x:Teams) {
    			if(thisTeam.equals(x)) {
    				double minimum = Double.parseDouble(JOptionPane.showInputDialog("Great you got offer from one of the best team.\n What is your minimum amount for"));
    				if(minimum > offer) {
    					JOptionPane.showMessageDialog(null, "Congratuation! You success with contract.");
    				}
    				else if(minimum < offer) {
    					JOptionPane.showMessageDialog(null, " less than minimum");
    				}
    				
    			}
    			
    			
    		}
    		
    	}
    	else {
    		JOptionPane.showMessageDialog(null, "You are typing wrong way");
    	}
    	
    }
    
    public void printData() {
    	System.out.println("Athlete Data:" + "\n name: " + name + "\n Height: " + height + "\n Weight: " + weight);
    	System.out.println("Game Status: \n vertical: " + vertical + "\n Point per Game: " + ppg + "\n Shooting percentage: " + shootP);
    }
    
    public void Dunk() {
    	System.out.println("Dunk on your face!");
    }
    
    public String getName() {
    	return super.name;
    }

    public void setName(String newName) {
    	super.name = newName;
    }
    
    public double getHeight() {
    	return super.height;
    }
    
    public void setHeight(double newHeight) {
    	super.height = newHeight;
    }
    
    public double getWeight() {
    	return super.weight;
    }
    public void setWeight(double newWeight) {
    	 super.weight = newWeight;
     }

	public double getPpg() {
		return ppg;
	}

	public void setPpg(double ppg) {
		this.ppg = ppg;
	}

	public double getVertical() {
		return vertical;
	}

	public void setVertical(double vertical) {
		this.vertical = vertical;
	}

	public double getShootP() {
		return shootP;
	}

	public void setShootP(double shootP) {
		this.shootP = shootP;
	}
    
    

}
