package com.Yoshi.Athlete;

import javax.swing.JOptionPane;

public class AthleteRunner {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//create object for each sports.
         Football FootBallPlayer = new Football("Charlie", 6.5, 225.0, 35.6, 23, 4.4, "kicker");
         Basketball BasketBallPlayer = new Basketball("Yoshi", 5.8, 148.8, 38.0, 45.0, 88.8);
         int t = 0;
         t += 1;
         
        
         do {
        	 int selection= Integer.parseInt(JOptionPane.showInputDialog("Choose sports\n1. Football\n2. Baseball\n3.Exit"));
        	 switch(selection) {
        	 
        	 case 1: 
        		 FootBallPlayer.sign_contract();
        		 FootBallPlayer.obtainSponser();
        		 break;
        	 case 2: 
        		 BasketBallPlayer.sign_contract();
        		 BasketBallPlayer.obtainSponser();
        		 break;
        	 case 3:
        		 t = 1;
        		 
        	 }
        	 
         }while(t == 0);
	}

}
