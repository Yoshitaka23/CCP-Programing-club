package com.Yoshi.Athlete;

abstract public class Athlete {
	//protected so only same package can access.
	protected String name;
	protected double height;
	protected double weight;
	
	//constructor 
	public Athlete(String n, double h, double w) {
		name = n;
		height = h;
		weight = w;
				
	}
	
	
	//abstract method
	abstract public void obtainSponser();
	
	abstract public void sign_contract();

	
	abstract public void printData(); //Data of athlete is different in each sport, so I made abstract method call printData
	
	

}
