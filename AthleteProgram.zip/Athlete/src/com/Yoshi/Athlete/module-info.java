module Athlete {
	requires java.desktop;
}